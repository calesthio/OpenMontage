# Skills index

- `youtube-factory-orchestrator` — name: youtube-factory-orchestrator
- `youtube-research-and-scripting` — name: youtube-research-and-scripting
- `licensed-footage-audit` — name: licensed-footage-audit
- `video-pipeline-ffmpeg` — name: video-pipeline-ffmpeg
- `video-rendering-remotion` — name: video-rendering-remotion
- `youtube-quality-gate` — name: youtube-quality-gate
- `youtube-publishing-analytics` — name: youtube-publishing-analytics
- `youtube-factory-self-improvement` — name: youtube-factory-self-improvement
