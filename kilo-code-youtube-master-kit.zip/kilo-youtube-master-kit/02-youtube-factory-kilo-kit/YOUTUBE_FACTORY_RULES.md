# Global rules for YouTube Factory tasks

For every task related to OpenMontage Factory or automated YouTube production:
- Explicitly inspect and use the relevant available Skills; do not rely on vague memory.
- Prefer official documentation and current repository source for tool/API behavior.
- Protect rights: no asset enters a final timeline without a traceable license/provenance record.
- Keep human approval before any public upload, scheduling, deletion or channel mutation.
- Build modular, testable stages and preserve job manifests for resumability.
- Run tests and a technical media QA gate; mark unperformed checks NOT_CHECKED.
- Record repeated failures and propose evidence-based improvements; never silently modify global config, install plugins, expose secrets or publish.
