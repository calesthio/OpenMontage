# Evaluation set

Keep stable benchmark tasks and expected outcomes. Run the same tasks before/after agent, Skill, MCP or pipeline changes. Record model/tool versions, pass rate, cost, runtime and human corrections.
