#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
GLOBAL_DIR="$HOME/.config/kilo"
AGENTS="$GLOBAL_DIR/AGENTS.md"
SKILL_DIR="$HOME/.kilo/skills/kilo-self-improvement"
SKILL_DEST="$SKILL_DIR/SKILL.md"
BEGIN='<!-- KILO_SELF_IMPROVEMENT_BEGIN -->'

mkdir -p "$GLOBAL_DIR" "$SKILL_DIR"
if [ -f "$AGENTS" ]; then
  STAMP="$(date +%Y%m%d-%H%M%S)"
  cp -p "$AGENTS" "$AGENTS.bak-$STAMP"
  if grep -Fq "$BEGIN" "$AGENTS"; then
    echo 'Managed instruction block already exists; left it unchanged.'
  else
    printf '\n\n' >> "$AGENTS"
    cat "$ROOT/AGENTS.global.md" >> "$AGENTS"
    echo "Added global instructions: $AGENTS"
  fi
else
  cp "$ROOT/AGENTS.global.md" "$AGENTS"
  echo "Created global instructions: $AGENTS"
fi
cp "$ROOT/skills/kilo-self-improvement/SKILL.md" "$SKILL_DEST"
echo "Installed Skill: $SKILL_DEST"
echo 'Done. Restart Kilo Code and follow PROMPT_FIRST_RUN.md.'
echo 'No MCP server was installed and kilo.jsonc was not modified.'
