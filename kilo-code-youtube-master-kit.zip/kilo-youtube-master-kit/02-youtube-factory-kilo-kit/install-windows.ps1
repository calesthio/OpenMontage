$ErrorActionPreference = "Stop"
$source = Join-Path $PSScriptRoot "skills"
$dest = Join-Path $HOME ".kilo\skills"
New-Item -ItemType Directory -Force -Path $dest | Out-Null

Get-ChildItem -Directory $source | ForEach-Object {
    $target = Join-Path $dest $_.Name
    if (Test-Path $target) {
        $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
        Copy-Item -Recurse $target "$target.backup-$stamp"
        Write-Host "Backed up existing skill: $target"
        Remove-Item -Recurse -Force $target
    }
    Copy-Item -Recurse $_.FullName $target
    Write-Host "Installed skill: $($_.Name)"
}

$rules = Join-Path $PSScriptRoot "YOUTUBE_FACTORY_RULES.md"
$rulesTarget = Join-Path $HOME ".kilo\YOUTUBE_FACTORY_RULES.md"
Copy-Item $rules $rulesTarget -Force
Write-Host ""
Write-Host "Skills installed to $dest"
Write-Host "Rules copied to $rulesTarget"
Write-Host "Review the rules and merge into your global AGENTS.md if desired."
Write-Host "Restart Kilo Code or use /reload, then verify skill discovery."
