# Kilo Code evaluation set

Repeat the same tasks before and after any meaningful agent-rule/Skill/MCP change. Record only observed facts.

| ID | Task | Pass criteria | Baseline | New result | Regression? | Notes |
|---|---|---|---|---|---|---|
| E1 | Fix a small reproducible bug | Test added or existing test proves fix; no unrelated edits | | | | |
| E2 | Multi-file feature | Plan followed, tests pass, public behavior documented | | | | |
| E3 | Find behavior in large codebase | Relevant symbols/files found without broad unnecessary file dumps | | | | |
| E4 | Use an unfamiliar library API | API checked against current official docs; no invented method | | | | |
| E5 | Verify UI/browser workflow (if applicable) | Actual browser/test evidence; result reproducible | | | | |
