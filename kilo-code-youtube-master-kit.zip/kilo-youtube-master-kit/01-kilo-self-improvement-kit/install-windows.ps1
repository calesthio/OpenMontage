$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$globalDir = Join-Path $HOME '.config\kilo'
$agentsPath = Join-Path $globalDir 'AGENTS.md'
$skillSource = Join-Path $root 'skills\kilo-self-improvement\SKILL.md'
$skillDir = Join-Path $HOME '.kilo\skills\kilo-self-improvement'
$skillDest = Join-Path $skillDir 'SKILL.md'
$begin = '<!-- KILO_SELF_IMPROVEMENT_BEGIN -->'

New-Item -ItemType Directory -Force -Path $globalDir | Out-Null
New-Item -ItemType Directory -Force -Path $skillDir | Out-Null

if (Test-Path $agentsPath) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    Copy-Item $agentsPath "$agentsPath.bak-$stamp"
    $current = Get-Content -Raw -Encoding UTF8 $agentsPath
} else {
    $current = ''
}

$block = Get-Content -Raw -Encoding UTF8 (Join-Path $root 'AGENTS.global.md')
if (-not $current.Contains($begin)) {
    if ($current.Trim().Length -gt 0) {
        $current = $current.TrimEnd() + "`r`n`r`n" + $block
    } else {
        $current = $block
    }
    Set-Content -Encoding UTF8 -Path $agentsPath -Value $current
    Write-Host "Added global instructions: $agentsPath"
} else {
    Write-Host 'Managed instruction block already exists; left it unchanged.'
}

Copy-Item -Force $skillSource $skillDest
Write-Host "Installed Skill: $skillDest"
Write-Host 'Done. Restart Kilo Code / VS Code, then use PROMPT_FIRST_RUN.md.'
Write-Host 'No MCP server was installed and kilo.jsonc was not modified.'
