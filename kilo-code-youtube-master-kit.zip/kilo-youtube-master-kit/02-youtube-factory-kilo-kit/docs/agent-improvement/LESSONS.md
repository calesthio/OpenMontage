# Lessons learned

Add only reproducible, evidence-backed lessons. Include date, symptom, root cause, fix, test and confidence.
