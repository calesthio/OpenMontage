# GitHub shortlist for building the YouTube Factory

Checked as a shortlist for architecture and integration planning on 2026-10-17. Repository status, API behavior, dependencies and licenses can change; verify before adopting.

| Project | Role | Recommendation / caveat |
|---|---|---|
| https://github.com/Jakeschincariol/youtube-agent-skill | 11 YouTube channel Skills: scripts, title/thumbnail packaging, retention, EDL, Shorts | MIT. Written for Claude Code; adapt Skill files, audit scripts and dependencies before Kilo use. |
| https://github.com/Jakeschincariol/chatgpt-youtube-agent-skill | Compatible-style YouTube workflow Skills | Compare with above; avoid duplicate skills with overlapping names. |
| https://github.com/remotion-dev/skills | Remotion agent skills | Use when implementing Remotion compositions and rendering. |
| https://github.com/remotion-dev/remotion | Programmatic video creation and batch rendering with React | Check Remotion commercial license terms. |
| https://github.com/FFmpeg/FFmpeg | Video/audio processing primitives | Check the exact build's LGPL/GPL configuration and redistribution obligations. |
| https://github.com/vapvarun/youtube-mcp | Self-hosted YouTube Data API MCP: upload/metadata/thumbnails/playlists | Requires Google OAuth setup; review license, scopes, API quota and security. |
| https://github.com/adamanz/youtube-mcp-server | YouTube upload MCP | Alternative; compare maintenance, API behavior, security and license before choosing. |
| https://github.com/github/github-mcp-server | GitHub issues, PRs and repository integration | Optional; use least-privilege token. |
| https://github.com/upstash/context7 | Current documentation lookup MCP | Optional external service; check limits and data handling. |
| https://github.com/microsoft/playwright-mcp | Browser automation | Useful for testing a factory dashboard, not required for a CLI-only factory. |
| https://github.com/oraios/serena | Semantic code navigation and editing | Optional; add if repository size makes code exploration costly. |
| https://github.com/Poseidoncode/superpowers-mcp | Planning, TDD and debugging workflow tools | Optional; verify Kilo setup instructions and inspect code before execution. |
| https://github.com/n8n-io/n8n | Workflow orchestration and integrations | Optional; fair-code license, check commercial terms. |
| https://github.com/yt-dlp/yt-dlp | Downloader for authorized media | Do not use to harvest third-party YouTube footage; download only content you have permission to obtain. |
| https://github.com/yt-dlp/FFmpeg-Builds | FFmpeg builds used by yt-dlp | Review build configuration and license obligations. |
| https://github.com/modelcontextprotocol/servers | Reference MCP server implementations | Some components may be archived; choose maintained projects individually. |
| https://github.com/udecode/skiller | Skill synchronization across agents | Optional; verify current Kilo paths and avoid overwriting project Skills. |
| https://github.com/Kilo-Org/kilo-marketplace | Kilo-compatible Skills, MCPs, agents and plugins catalog | Best first stop for Kilo-specific integration. |

## How to decide
Score each candidate on: verified compatibility, active maintenance, license fit, secrets/permissions, installation complexity, token/latency impact, testability and actual improvement on benchmark tasks. Do not equate GitHub stars with security or quality.
