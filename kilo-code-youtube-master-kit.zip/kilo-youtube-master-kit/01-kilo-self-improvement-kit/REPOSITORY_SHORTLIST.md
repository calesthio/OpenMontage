# Подборка репозиториев и инструментов для Kilo Code

Проверено по открытым README/документации и обсуждениям на 17 октября 2026 года. «Бесплатно» означает бесплатный код/базовое использование, если отдельно не сказано обратное; модель, API и вычисления могут быть платными. Совместимость с MCP-протоколом не всегда означает официальную интеграцию Kilo — настройку нужно проверить в своей версии.

## Начать с этих пяти

| Приоритет | Проект | Что даёт | Цена / оговорка | Ссылка |
|---|---|---|---|---|
| 1 | Kilo Marketplace | Каталог Skills, MCP, агентов и плагинов для экосистемы Kilo | Сам каталог открыт; каждый сторонний компонент отдельно проверяйте | https://github.com/Kilo-Org/kilo-marketplace |
| 2 | Официальные Kilo Skills | Стандартные повторяемые workflows для разработки и AI-задач | Open source; устанавливать все или только конкретный skill | https://github.com/Kilo-Org/skills |
| 3 | Superpowers MCP (Kilo target) | Planning, brainstorming, TDD, отладка и выполнение планов через MCP | Репозиторий доступен бесплатно; вызовы LLM могут стоить денег | https://github.com/Poseidoncode/superpowers-mcp |
| 4 | Context7 | Актуальная/version-specific документация библиотек и SDK | Hosted endpoint есть в официальном примере Kilo; квоты/ключ могут зависеть от сервиса | https://github.com/upstash/context7 |
| 5 | jCodeMunch MCP | Структурный поиск по символам, чтобы получать нужные функции вместо больших файлов | README указывает free personal use; коммерческое использование имеет лицензионные условия. Экономия токенов в README — benchmark автора, не гарантия | https://github.com/jgravelle/jcodemunch-mcp |

## Ещё полезные репозитории

| # | Проект | Когда пригодится | Совместимость и ограничения | Ссылка |
|---:|---|---|---|---|
| 6 | Serena | Семантическая навигация, извлечение символов, правки и рефакторинг | MCP-совместимый инструмент; проверьте рекомендуемую установку в README, не берите старые marketplace-команды | https://github.com/oraios/serena |
| 7 | GitHub MCP Server | Работа с репозиториями, issue, PR и CI из агента | Официальный server, но для авторизованных действий нужен GitHub token с минимальными правами | https://github.com/github/github-mcp-server |
| 8 | Playwright MCP | Реальное управление браузером, проверка страниц и UI-потоков | Open source; нужна локальная/browser-среда. Подключать только для задач, где нужен браузер | https://github.com/microsoft/playwright-mcp |
| 9 | Exa MCP Server | Поиск в интернете и обход страниц для исследований | Требует API/квоты; не считать безлимитным бесплатным | https://github.com/exa-labs/exa-mcp-server |
| 10 | Repomix | Пакует кодовую базу в единый файл для разового анализа/рефакторинга | Бесплатный open-source CLI, не MCP; не отправлять наружу секреты и большие частные репозитории без проверки | https://github.com/yamadashy/repomix |
| 11 | GitNexus | Граф зависимостей/вызовов и индекс кодовой базы | Полезен большим проектам; в опубликованной таблице интеграций Kilo явно не перечислен — потребуется ручная MCP-настройка и проверка | https://github.com/johnman/gitnexus |
| 12 | Skiller | Синхронизация Skills/rules для нескольких coding agents | Его актуальная таблица всё ещё показывает некоторые legacy-пути `.kilocode`; проверьте, что файлы попали в активные пути вашей версии Kilo, а не полагайтесь на установку вслепую | https://github.com/udecode/skiller |
| 13 | Ruler / agent-rules | Общие правила и распространение настроек между агентами | В проекте написано, что Skills support экспериментальный; не делать основой системы без проверки результата | https://github.com/acumenix/agent-rules |
| 14 | Model Context Protocol servers | Эталонные/полезные серверы: Fetch, Filesystem, Git и др. | В репозитории есть архивированные компоненты; выбирайте конкретный поддерживаемый сервер, а не устанавливайте всё подряд | https://github.com/modelcontextprotocol/servers |
| 15 | Kilo Context Condensing docs | Управление auto-compaction/pruning, чтобы длинные чаты не забивали контекст | Уже встроенная функция Kilo; проверьте настройки `compaction.auto` и `compaction.prune` | https://kilo.ai/docs/customize/context/context-condensing |
| 16 | Kilo custom instructions | Глобальные `AGENTS.md` и инструкции на все проекты | Это не плагин — базовый механизм постоянных правил. Глобальный путь для Kilo: `~/.config/kilo/AGENTS.md` | https://kilo.ai/docs/customize/custom-instructions |
| 17 | Kilo custom agents / modes | Разделить роль планировщика, кодера, тестировщика, ревьюера | Предпочитать современные agent Markdown files; не смешивать с legacy `custom_modes.yaml` без проверки версии | https://kilo.ai/docs/customize/custom-modes |
| 18 | Kilo Plugins docs | Создание/подключение плагинов, хуков, custom tools и изменяемого поведения runtime | Плагины запускают код с правами пользователя: изучать исходники и permissions до установки | https://kilo.ai/docs/automate/extending/plugins |

## Форумы и community-сигналы

- Обсуждение о Skills/rules: один пользователь сообщает, что Kilo иногда подтверждает правила словами, но фактически не применяет их; совет сообщества — использовать общепринятый `AGENTS.md` и явно перечислять Skill triggers. Это единичные сообщения, а не систематический бенчмарк: https://www.reddit.com/r/kilocode/comments/1soyghb/kilo_code_project_rules_skills/.
- Обсуждение делегирования custom agents: пользователь сообщает, что инструкции в `AGENTS.md` сами по себе не заставляли модель переключаться; совет — держать короткие If/Then правила также в Role Definition конкретного агента и делать `whenToUse` описания отличимыми: https://www.reddit.com/r/kilocode/comments/1ra56h3/agents_not_switching_to_custom_modes_in_kilo/.
- В сообществах повторяется тема ненужного чтения крупных файлов; jCodeMunch даёт структурированный retrieval, но его эффект зависит от того, использует ли агент инструменты вместо brute-force чтения: https://github.com/jgravelle/jcodemunch-mcp.

## Рекомендуемый минимальный набор

1. **Всем проектам:** глобальный `AGENTS.md` + официальный Kilo Skills.
2. **Большие кодовые базы:** выбрать **либо jCodeMunch, либо Serena** сначала; сравнить их на нескольких одинаковых задачах.
3. **Новые/неизвестные API:** Context7.
4. **Тесты веб-интерфейса:** Playwright MCP.
5. **Работа с PR/issues:** GitHub MCP с минимальными правами.
6. **Разработка по строгому процессу:** Superpowers MCP.
7. Exa, GitNexus, Skiller, Ruler и прочие добавлять, только если есть конкретная задача, и после проверки совместимости.

## Важная разница

- **Skill** учит процедуре и подгружается по релевантности.
- **MCP** предоставляет вызываемый инструмент; наличие в конфиге не значит, что модель вызвала его.
- **Plugin/hook** способен влиять на runtime и лучше подходит для механического enforcement, но имеет самый высокий риск и должен тестироваться отдельно.
- **AGENTS.md / agent prompt** — слой постоянных инструкций. Он не гарантирует идеального следования каждой модели, поэтому добавляйте видимую проверку и контрольные задачи.
