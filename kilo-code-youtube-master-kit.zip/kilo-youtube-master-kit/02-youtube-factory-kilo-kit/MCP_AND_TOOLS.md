# Recommended stack for OpenMontage Factory (Kilo Code)

Start with the local core, then add only what a measured bottleneck requires.

## Core local tools
- **FFmpeg + ffprobe** — ingest, transcode, render simple edits, probe outputs. Repository: https://github.com/FFmpeg/FFmpeg
- **Remotion** — template-driven React compositions, motion graphics and batch rendering. https://github.com/remotion-dev/remotion
  - License warning: Remotion has special commercial licensing terms for some use cases. Check before commercial deployment.
- **Python or Node.js** — orchestration, manifests, queues, retries, tests. Pin dependencies and lockfiles.
- **SQLite** initially for job state and asset ledger; migrate only if measured concurrency needs it.
- **Git + automated tests** — reproducibility and rollback.

## Skills
- Official Kilo skills: https://github.com/Kilo-Org/skills
- YouTube agent skills (MIT): https://github.com/Jakeschincariol/youtube-agent-skill
  - Created for Claude Code; adapt/copy selected `SKILL.md` files into Kilo's `.kilo/skills/` or `~/.kilo/skills/`, check their scripts and dependencies. Do not assume the Claude plugin wrapper works in Kilo. This project includes channel strategy, scripting, packaging, retention, edit decisions and Shorts workflows.
- Remotion skills: https://github.com/remotion-dev/skills
  - Use for Remotion-specific coding, rendering and composition guidance.
- Superpowers MCP: https://github.com/Poseidoncode/superpowers-mcp
  - Optional workflow aid for planning/TDD/debugging; verify current compatibility and inspect setup before running.

## MCP / APIs
- **Context7**: https://github.com/upstash/context7 — current library documentation; optional remote service and possible limits.
- **GitHub MCP**: https://github.com/github/github-mcp-server — repository/issue/PR workflows; token permissions should be minimal.
- **YouTube MCP**: https://github.com/vapvarun/youtube-mcp — self-hostable YouTube Data API integration with OAuth. Verify current project license, API scope, quotas and security before use.
- Alternative YouTube upload MCP: https://github.com/adamanz/youtube-mcp-server — review maintenance and dependencies before selecting.
- **Playwright MCP**: https://github.com/microsoft/playwright-mcp — browser-based UI tests, only if the factory has a web dashboard.
- **Serena**: https://github.com/oraios/serena — semantic code navigation; optional if large codebase exploration is a bottleneck.
- **n8n**: https://github.com/n8n-io/n8n — optional workflow orchestration, but its fair-code license is not equivalent to a permissive OSI open-source license. Check commercial terms before embedding/reselling.

## Asset sources
Do not install an asset downloader before defining allowed sources and the rights ledger. Prefer official APIs from licensed providers or a human-approved local asset library. For each provider, store the exact license terms and a record of retrieval.
Do not use yt-dlp to scrape YouTube videos for stock footage. `yt-dlp` is a useful downloader for content you are authorized to download, but a tool's existence is not permission to reuse someone else's work.

## Suggested initial MCP set
1. Context7, if network access is acceptable.
2. GitHub MCP, only if you want Kilo to manage issues/PRs with approved access.
3. YouTube MCP only after a local prototype is tested; start with read-only or draft/unlisted workflows and keep public publishing approval manual.

Do not connect all MCPs at once. More tools can increase prompt clutter, latency, attack surface and troubleshooting complexity. Record why each tool is needed and measure whether it helps.
