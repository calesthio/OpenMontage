#!/usr/bin/env bash
set -euo pipefail
SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/skills"
DEST="$HOME/.kilo/skills"
mkdir -p "$DEST"
stamp="$(date +%Y%m%d-%H%M%S)"

for skill_dir in "$SOURCE"/*; do
  [ -d "$skill_dir" ] || continue
  name="$(basename "$skill_dir")"
  target="$DEST/$name"
  if [ -e "$target" ]; then
    cp -R "$target" "$target.backup-$stamp"
    rm -rf "$target"
    echo "Backed up existing skill: $target.backup-$stamp"
  fi
  cp -R "$skill_dir" "$target"
  echo "Installed skill: $name"
done

cp "$(dirname "$SOURCE")/YOUTUBE_FACTORY_RULES.md" "$HOME/.kilo/YOUTUBE_FACTORY_RULES.md"
echo
echo "Skills installed to: $DEST"
echo "Rules copied to: $HOME/.kilo/YOUTUBE_FACTORY_RULES.md"
echo "Review and merge rules into your global AGENTS.md if desired."
echo "Restart Kilo Code or use /reload, then verify skill discovery."
