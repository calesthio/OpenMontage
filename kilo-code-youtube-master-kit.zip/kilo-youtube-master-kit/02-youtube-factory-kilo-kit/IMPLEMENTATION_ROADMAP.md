# Roadmap: OpenMontage Factory

## Phase 0 — Audit, no destructive changes
- Read the current repository and identify implemented vs planned features.
- Map current pipeline, runtime, storage, queue, UI, tests and deployment.
- Create `docs/architecture/current-state.md` and `docs/architecture/target-state.md`.
- Run existing tests and record baseline; do not replace the stack before understanding it.

## Phase 1 — One reliable video end-to-end
- Define a typed job manifest and stable job ID.
- Accept a script and human-approved local/licensed assets.
- Store source/license metadata and SHA-256 checksums in an asset ledger.
- Build a simple EDL/timeline with clips, narration, music, subtitles and transitions.
- Render with FFmpeg for straightforward edits; add Remotion only where templates/animation require it.
- Generate a machine-readable QA report and a human-review preview.
- Deliver one finished local MP4; no auto-publishing.

## Phase 2 — Resumable production pipeline
- Model each stage with status, input/output, retries, timeout, error classification and provenance.
- Make stages idempotent and resumable after crash.
- Keep artifacts in per-job directories; prevent path traversal and unsafe filenames.
- Add structured logs, queue limits, cancellation and disk-space checks.
- Write integration tests for failed downloads, corrupt media, missing audio and interrupted renders.

## Phase 3 — Research and creative workflow
- Add source-backed research and a claim-to-source ledger.
- Generate outline, script, visual beat sheet, title/thumbnail pair and narration.
- Separate facts from creative framing; human review for sensitive or uncertain claims.
- Add versioned channel voice profile and format presets (long-form / Shorts).

## Phase 4 — Asset-provider adapters
- Integrate one approved provider at a time through a provider interface.
- Require license metadata and usage terms before asset can be accepted.
- Support local asset library as a first-class provider.
- Add cache, attribution and license-change review; quarantine unverified assets.
- Never scrape YouTube as a stock library or bypass access controls.

## Phase 5 — Quality gates
- Validate media technical specs using ffprobe.
- Detect black frames, frozen frames, audio clipping/silence and subtitle drift where tools permit.
- Run factual claim audit, title/thumbnail alignment and rights completeness checks.
- Mark checks PASS/FAIL/NOT_CHECKED with evidence.
- Block publishing if required checks fail.

## Phase 6 — YouTube integration
- Use the official YouTube Data API or an audited MCP adapter.
- Keep OAuth credentials out of source and logs; least privilege.
- Add quota accounting, resumable upload, retries and explicit publication states.
- Default to draft/unlisted. Public publishing and scheduling require explicit approval.
- Test with a private/unlisted test channel before production.

## Phase 7 — Analytics and feedback loop
- Import permitted analytics exports/API metrics with timestamp and measurement window.
- Track CTR, retention, average view duration, production time, failure rate, rights coverage and cost per finished minute.
- Compare similar videos against channel baselines; do not infer causation from a single upload.
- Add controlled experiments and record outcomes.

## Phase 8 — Self-improvement and hardening
- Keep LESSONS.md, BACKLOG.md, EVALS.md and CHANGELOG.
- Require regression tests for repeated failures.
- Test candidate changes on fixed benchmark tasks before adoption.
- Require review for dependency, license, permissions, secret, publishing and migration changes.
- Add CI, linting, type checking, dependency scanning and backup/restore tests.

## Acceptance criteria for the first milestone
- A test job produces a valid local MP4 from a manifest and approved assets.
- Each asset has a complete rights record or is rejected.
- A failed render can be retried without corrupting prior outputs.
- QA produces PASS/FAIL/NOT_CHECKED evidence.
- No upload/publication happens automatically.
- Unit and integration tests cover the critical path.
